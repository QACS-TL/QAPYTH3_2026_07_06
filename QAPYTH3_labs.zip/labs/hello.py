
print("Hello world!")
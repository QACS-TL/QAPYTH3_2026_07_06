mytuple = 'eggs', 'bacon', 'spam', 'tea'

# Value error: too many values to unpack
# x, y, z = mytuple

# we can designate any variable on the left as a tuple by prefixing with an asterisk *
x, y, *z = mytuple

*a, b, c = mytuple

a, *b, c = mytuple

# tuple2 = mytuple
t = tuple(sorted(list(mytuple)))
print(t)
print(x, x, z)


t1 = 'cat', 'dog', 'python', 'mouse', 'camel'
t2 = 'kelp', 'crab', 'lobster', 'fish'
for a, *b, c in t1, t2:
    print(a, b, c)

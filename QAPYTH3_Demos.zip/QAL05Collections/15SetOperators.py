s6 = {23, 42, 66, 123}
s7 = {123, 56, 27, 42}
s8 = {123, 56, 28, 43}

print(s6 & s7)  # intersection
print(s6 | s7)  # union
print(s6 - s7)  # difference
print(s6 ^ s7)  # symmetric difference

print(s6.intersection(s7))  # intersection
print(s6.union(s7))  # union
print(s6.difference(s7))  # difference
print(s6.symmetric_difference(s7))  # symmetric difference

mydict = {'Australia':'Canberra', 'Eire':'Dublin',
          'France':'Paris', 'Finland':'Helsinki',
          'UK':'London', 'US':'Washington'
}

country = ""
# print("enter countries and their capitals, or a Q to quit")
# while country != "Q":
#     country = input("Please enter a country")
#     capital = input("Please enter the capital of the country")
#     if country != "Q":
#         mydict[country] = capital
for k in mydict:
    print(f"{k} associated value {mydict[k]}")

for k in mydict.keys():
    print(f"{k} associated value {mydict[k]}")


for v in mydict.values():
    print(f"{v}")


for k, v in mydict.items():
    print(f"{k} associated value {v}")


country = 'Iceland'
mydict[country] = 'Reykjavik'

print(mydict)

mylist = {'Bill', 'Ted', 'Anthia'}
mydict = {}.fromkeys(mylist)
mydict['Bill'] = "Smith"
mydict['Anthia'] = "Turner"
print(mydict)
keys = list(mydict)
print(keys)

my_empty_set = set()

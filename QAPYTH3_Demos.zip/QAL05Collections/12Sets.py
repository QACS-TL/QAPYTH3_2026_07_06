s1 = {5, 6, 7, 8, 5}
print(s1)

my_list = [9, 10, 11, 12, 9]
s2 = set(my_list)


# frozenset is the same as set except the frozensets are immutable
# which means that elements from the frozenset cannot be added or removed once created
s3 = frozenset([9, 10, 11, 12, 9])
print(s3)



mydict = {'cob': "stuff", 'dof':"more stuff"}
# del mydict['dob']

if not mydict.pop('dob', False):
    print("Dictionary doesn't contain 'dob' as a key")

print(mydict)
countries = []
for line in open('12country.txt'):
    countries.append(line.split(','))

countries.sort(key=lambda c: str(c[0]))

for line in countries:
    print(','.join(line), end='')





def print_vat(gross=0.0, vatpc=17.5, *, message='Summary:'):
   net = gross/(1 + (vatpc/100))
   vat = gross - net
   print(message, 'Net: {0:5.2f} Vat: {1:5.2f}'.format(net, vat))

print_vat(vatpc=15, gross=9.55, message="woo hoo")
print_vat()

print_vat(gross=15) # Will crash


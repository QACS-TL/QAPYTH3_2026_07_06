def make_list(txt, times):
   res = str(txt) * times
   return res

word = "Bananas"
repeat_count = 5
mylist = make_list(txt=word, times=repeat_count)
print(mylist)

mylist = make_list(times=6, txt="banana")
print(mylist)

mylist = make_list("'Ello ", 3)
print(mylist)


# Program : 01FileRead
# Purpose : Example to open and read file

file = open("01ShakespeareanQuotes.txt","r")
print("First line:")
print(file.readline())
print("Second line:")
print(file.readline())
print("Rest of file:")
print(file.read())
print("Blank line:")
print(file.readline())
file.close()

with open("01ShakespeareanQuotes.txt","r") as file:
    print("First line:")
    print(file.readline())
    print("Second line:")
    print(file.readline())
    print("Rest of file:")
    print(file.read())
    print("Blank line:")
    print(file.readline())

file = open("01ShakespeareanQuotes.txt","r")
for line in file:
    print(f"{line}", end="")

for i in range(1, 11):
    print(i)

file = open("01ShakespeareanQuotes.txt","r")
for i, line in enumerate(file, 1):
    print(f"{i}: {line}", end="")


# more code here
print()
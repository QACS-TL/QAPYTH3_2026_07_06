import tarfile
import time

filename = 'qapyth3_linux.tgz'
if tarfile.is_tarfile(filename):
    tfo = tarfile.open(filename, 'r')
    
    for mdata in tfo.getmembers():
        tm = time.localtime(mdata.mtime)
        print("%-12s %s" % (mdata.name, 
                 time.strftime("%d/%m/%Y %X", tm)))
    tfo.close()

import re

emails = 'Y-LOCN-Confidence: 0.8475'

emails = emails.rstrip()
print(re.findall('^Y-.*: [0-9.]+', emails))




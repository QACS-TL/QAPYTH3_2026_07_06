import sys

def my_func():
    try:
        f = open("foo")
    finally:
        print("Finally block", file=sys.stderr)  # use to ensure resources are cleaned up
    print("If an unhandled exception occurs we won't see this message")

try:
    my_func()
except OSError:
    print("An OS error occurred", file=sys.stderr)

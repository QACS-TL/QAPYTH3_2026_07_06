filename = "foo"
errmsg = ""
try:
    f = open(filename)
    print("banana")

except FileNotFoundError:
    errmsg = filename + " not found"
except (TypeError, ValueError):
    errmsg = "Invalid filename"
# ...
print("Stuff done here if error occurs")

if errmsg != "":
    exit(errmsg)

print("Stuff NOT done here if error occurs")

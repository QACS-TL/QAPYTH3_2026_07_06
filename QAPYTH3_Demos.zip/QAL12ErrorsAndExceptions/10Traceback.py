import sys

try:
    open("some file name")
except FileNotFoundError as err:
    tipe, val, tb = sys.exc_info()
    print("Exception lineno:", tb.tb_lineno)
    print("Exception type:", tipe)
    print("Exception value:", val)


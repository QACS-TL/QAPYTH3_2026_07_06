



my_tuple = 'eggs', 'bacon', 'spam', 'tea'
print(my_tuple)
print(my_tuple[0])
print(my_tuple[-1])

# Can be reassigned but not altered
# my_tuple[2] = 'John'
# my_tuple.append('fried-slice')

my_tuple = ('apples', 'bananas', 'carrots', 'dates')
print(my_tuple)

s = "abc"
s = s + "def"

print(s[2])
print(s)

print("Hello World")
a = 6
b = 7
c = a + b
print(c)
print(a)
mydata = input("Please enter some data ")
print("You entered: ", mydata)

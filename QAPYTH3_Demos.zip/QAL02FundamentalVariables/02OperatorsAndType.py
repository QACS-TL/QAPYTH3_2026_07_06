# Note lines 4 and 9 are identical but are they doing the same thing?
import sys

def my_func():
    print("Hello from my func")


def bark(number_of_times):
    for i in range(0, number_of_times):
        print("woof")


print(r"C:\nokia\tone")


a = 42
b = 9
a += 1
c = a + b
print(c)


# bark(4)

a = 'Hello '
b = 'World!'
c = a + b
print(c)
print(c.upper())
print(type(a))






name = "Rishi Sunak"

print(name)
print(name.upper())
print(name)

number = 10

print(number)
print(number.upper())
print(number)

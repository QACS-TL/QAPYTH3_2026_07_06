

lista = [1, 2, 3, "eggs"]
listb = [1, 2, 3, "eggs"]
if lista == listb:
    print("Same!")

if "eggs" in lista:
    print("It eggists!")


i = 15
# Spot the difference - part 1
if i < 10:
    print("That’s low")
else:
    if i < 15:
        print("That’s middling")
    else:
        print("That’s high")

# Spot the difference - part 2
if i < 10:
    print("That’s low")
elif i < 15:
    print("That’s middling")
else:
    print("That’s high")


# match case example
http_code = "418"

match http_code:
    case "200":
        print("OK")
    case "404":
        print("Not Found")
    case "418":
        print("Some other problem")
    case _:
        print("Code not found")




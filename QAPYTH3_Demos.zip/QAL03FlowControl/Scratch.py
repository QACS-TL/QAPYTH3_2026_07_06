mybreakfast=('eggs', 'bacon', 'spam', 'tea', 'beans', 'mushrooms')

# Get entries between 2 locations (2nd and 4th) (do this in 3 different ways)
print(mybreakfast[1:4])
print(mybreakfast[1:-2])
print(mybreakfast[-5:-2])
print(mybreakfast[-5:4])

# Get entries from 2nd to end
print(mybreakfast[1:])
print(mybreakfast[1:6])
print(mybreakfast[-5:6])
print(mybreakfast[-5:])

# Get entries from first to third (eggs - spam)
print(mybreakfast[0:3])
print(mybreakfast[0:-3])
print(mybreakfast[-6:3])
print(mybreakfast[-6:-3])

cheese = ['Cheddar', 'Camembert', 'Brie', 'Stilton', 'Wensleydale']
# remove the middle 3 items from the cheese LIST
del cheese[1:4]
print(cheese)


# remove the middle 3 items from the mybreakfast TUPLE
mylist = list(mybreakfast)
del mylist[1:4]
mybreakfast = tuple(mylist)

print(mybreakfast)

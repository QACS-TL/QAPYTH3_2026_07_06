# What is wrong with the following code?
fave_num = input("Please enter your favourite number: ")
if fave_num.isnumeric():
    fave_num = int(fave_num)
else:
    print("Not a number")
    exit()
res = fave_num % 10
is_divisible_by_ten = "is"
if res != 0:
   is_divisible_by_ten = "is NOT"
print(f"Your favourite number {fave_num} {is_divisible_by_ten} divisible by 10!")


# What kind of lists are the following?
cars = "Ford", "Vauxhall", "Renault", "Seat"

trees = ["Elm", "Oak", "Rowan", "Elm"]

elements = {1: "Hydrogen", 2: "Helium", 3: "Lithium", 4: "Beryllium", 1: "Hydrogen"}

windspeeds = ("Calm", "Light Air", "Light Breeze", "Moderate Breeze", "Fresh Breeze", "Strong Breeze", "Near Gale", "Gale", "Strong Gale", "Storm", "Violent Storm", "Hurricane")


# determine if an entry with a specified key is in elements and what is its associated value
key = 1
if key in elements:
    print(f"{key} is in elements! It's value is {elements[key]}")
else:
    print(f"{key} is NOT in elements!")

for k in elements:
    if k == key:
        print(f"{key} is in elements! It's value is {elements[key]}")
        break
else:
    print(f"{key} is NOT in elements!")

# determine if input tree name is in tress collection
possible_tree = input("Please enter the name of a possible tree: ")
if possible_tree in trees:
    print(possible_tree + " is in trees!")
else:
    print(possible_tree + " is not in trees")

for t in trees:
    if possible_tree == t:
        print(possible_tree + " is in trees!")
        break
else:
    print(possible_tree + " is not in trees")




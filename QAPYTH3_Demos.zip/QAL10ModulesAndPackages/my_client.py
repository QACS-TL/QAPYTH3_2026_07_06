import sys
#sys.path.append('./Finance')

import Finance.banking
from Finance.banking import deposit

newbal = deposit(100)
print(f"new balance is {newbal}")


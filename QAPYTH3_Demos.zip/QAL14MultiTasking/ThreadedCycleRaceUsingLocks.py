import time
from threading import Thread, Lock
print_lock = Lock()
winner_flag = False
winner = ""

def c_race_nl(racer, handicap):
    global winner_flag
    global winner
    for distance in range(0, 1001, 100):
        if winner_flag == True:
            break
        if distance == 1000:
            winner_flag = True
            winner = racer
        print(f"{racer} - {distance}m")
        time.sleep(handicap)

    return None

def c_race(racer, handicap):
    global winner_flag
    global winner
    for distance in range(0, 1001, 100):
        if winner_flag == True:
            break
        with print_lock:
            if distance == 1000:
                winner_flag = True
                winner = racer
            print(f"{racer} - {distance}m")
        time.sleep(handicap)

    return None

def c_race_ar(racer, handicap):
    global winner_flag
    global winner
    for distance in range(0, 1001, 100):
        if winner_flag == True:
            break
        print_lock.acquire()
        if distance == 1000:
            winner_flag = True
            winner = racer
        try:
            print(f"{racer} - {distance}m")
        finally:
            print_lock.release()
        time.sleep(handicap)
    return None


print("Race starting 3..2..1..")
t1 = Thread(target=c_race, args=("Racer 1", 1.637))
t2 = Thread(target=c_race, args=("Racer 2", 1.637))
t3 = Thread(target=c_race, args=("Racer 3", 1.637))
t4 = Thread(target=c_race, args=("Racer 4", 1.637))
t5 = Thread(target=c_race, args=("Racer 5", 1.637))
t6 = Thread(target=c_race, args=("Racer 6", 1.637))

# t1 = Thread(target=c_race_ar, args=("Racer 1", 1.637))
# t2 = Thread(target=c_race_ar, args=("Racer 2", 1.637))
# t3 = Thread(target=c_race_ar, args=("Racer 3", 1.637))
# t4 = Thread(target=c_race_ar, args=("Racer 4", 1.637))
# t5 = Thread(target=c_race_ar, args=("Racer 5", 1.637))
# t6 = Thread(target=c_race_ar, args=("Racer 6", 1.637))

# t1 = Thread(target=c_race_nl, args=("Racer 1", 1.637))
# t2 = Thread(target=c_race_nl, args=("Racer 2", 1.637))
# t3 = Thread(target=c_race_nl, args=("Racer 3", 1.637))
# t4 = Thread(target=c_race_nl, args=("Racer 4", 1.637))
# t5 = Thread(target=c_race_nl, args=("Racer 5", 1.637))
# t6 = Thread(target=c_race_nl, args=("Racer 6", 1.637))

t1.start() # Execute threads t1 - t6
t2.start()
t3.start()
t4.start()
t5.start()
t6.start()

t1.join() # Main thread waits all cars finish
t2.join()
t3.join()
t4.join()
t5.join()
t6.join()
print(f"The winner is {winner}")
print("Race finished")

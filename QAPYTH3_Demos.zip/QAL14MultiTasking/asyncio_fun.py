import asyncio

async def fetch_data(source):
    print(f"Fetching data from {source}...")
    await asyncio.sleep(2)  # Simulate network request
    print(f"Finished fetching from {source}")
    return f"Data from {source}"

async def main():
    # Run multiple tasks concurrently
    task1 = asyncio.create_task(fetch_data("API 1"))
    task2 = asyncio.create_task(fetch_data("API 2"))
    task3 = asyncio.create_task(fetch_data("API 3"))

    # Wait for all tasks to complete
    results = await asyncio.gather(task1, task2, task3)
    print(results)

asyncio.run(main())

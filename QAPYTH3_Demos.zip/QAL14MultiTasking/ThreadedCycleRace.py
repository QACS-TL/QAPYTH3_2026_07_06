import time
from threading import Thread

def c_race(racer, handicap):
    for distance in range(0, 1001, 100):
        print(f"{racer} - {distance}m")
        time.sleep(handicap)
    return None

print("Race starting 3..2..1..")
t1 = Thread(target=c_race, args=("Racer 1", 1.637))
t2 = Thread(target=c_race, args=("Racer 2", 1.587))
t1.start() # Execute threads t1 and t2
t2.start()
t1.join() # Main thread waits till t1 and t2 finish
t2.join()
print("Race finished")

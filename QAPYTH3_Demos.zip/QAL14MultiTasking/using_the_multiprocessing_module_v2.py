import time
import random
from multiprocessing import Process


def do_task(task):
    sleep_time = random.uniform(1, 5)  # Random sleep 1-5s
    print(f"{task} starting.. (Sleep: {sleep_time:.2f}s)")
    time.sleep(sleep_time)
    print(f"{task} finished.")


if __name__ == "__main__":
    p1 = Process(target=do_task, args=("Filter Logs",))
    p2 = Process(target=do_task, args=("Update DB",))
    p1.start()  # Start child processes
    p2.start()
    print("Main process continues to run...")
    p1.join()  # Wait for child procs to complete
    p2.join()
    print("All processes finished.")

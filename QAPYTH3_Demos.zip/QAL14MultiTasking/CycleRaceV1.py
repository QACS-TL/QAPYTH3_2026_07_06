import time

def c_race(racer, handicap):
    for distance in range(0, 1001, 100):
        print(f"{racer} - {distance} m")
        time.sleep(handicap)
    return None

print("Race starting 3..2..1..")
c_race("Racer 1", 1.637)
c_race("Racer 2", 1.587)
print("Race Finished")

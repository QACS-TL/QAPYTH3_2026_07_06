import httpx # Use instead of requests(blocking library) and works with asyncio
import asyncio

async def fetch_todo_data():
    print("Loading...")
    async with httpx.AsyncClient() as client:
        response = await client.get('https://jsonplaceholder.typicode.com/todos/')
        if response.status_code != 200:
            print("Data Not Collected")
            return None
        print("TODO Data Collected")
        return response.json()

async def fetch_comments_data():
    print("Loading...")
    async with httpx.AsyncClient() as client:
        response = await client.get('https://jsonplaceholder.typicode.com/comments/')
        if response.status_code != 200:
            print("Data Not Collected")
            return None
        print("Comments Data Collected")
        return response.json()

async def get_data():
    todo_data = await fetch_todo_data()
    comments_data = await fetch_comments_data()

    results = todo_data + comments_data
    return results

results = asyncio.run(get_data())
print(results)


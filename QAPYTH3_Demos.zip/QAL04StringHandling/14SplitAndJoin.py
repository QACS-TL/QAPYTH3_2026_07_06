line = 'root::0:0:superuser:/root:/bin/sh'
line2 = "Mary,Jones,34,1 the High Street"
elems = line.split(':')
elems2 = line2.split(',')

elems[0] = 'avatar'
elems[4] = 'The super-user (zero)'
line = ','.join(elems)

i = 3
s = "banana"
x = s.join(elems)
print(x)


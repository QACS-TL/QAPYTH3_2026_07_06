elements = {1: "Hydrogen", 2: "Helium", 3: "Lithium", 4: "Beryllium", 1: "Hydrogen"}

# determine if an entry with a specified key is in elements and what is its associated value

key = int(input("Get number"))
max_attempt_count = 2
count = 0
while not key in elements and count < max_attempt_count:
    count += 1
    key = int(input("Get number"))

if count == max_attempt_count:
    print(f"The key numbered {key} does not exist")
    exit()

print(elements[key])
# Miles of code here



var1 = 42
var2 = 'hello'
print("{name} {value}".format(value=var1, name=var2))
print(f"{var1} {var2}")


var1 = 234.123456
var2 = 234
var3 = 234.123456

s = f"var1: {var1:>+15.3f} var2: {var2:<-8d} var3:{var3:10.2f} the end"

print(s)


def frange(start, stop, step=0.25):
    if step == 0:
        return []

    curr = float(start)

    while curr < stop:
        yield round(curr, 2)
        curr += step





print(list(frange(1.1, 3)))
print(list(frange(1, 3, 0.33)))
print(list(frange(1, 3, 1)))  # Should print [1.0, 2.0]
print(list(frange(3, 1)))     # Should print an empty list
print(list(frange(1, 3, 0)))  # Should print an empty list
print(list(frange(-1, -0.5, 0.1)))

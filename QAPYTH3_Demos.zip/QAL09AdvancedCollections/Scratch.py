people = {'Ted': 55, 'Marie': 12, 'Abena': 37, 'Zuri': 18, 'Kofi': 17, 'Ade': 24, 'Anton': 5}


x = people.copy()

adults = [person for person in people if people[person] >= 18]
for x in adults:
    print(x)


"""
    Generate and display collection of numbers lazily...
"""
import sys

def get_numbers():
    """ Return an ENTIRE list of numbers """
    print("Executing get_numbers()..")
    numbers = []
    for x in range(1, 11, 1):
        if x % 2 == 0:
            numbers.append(x)
    return numbers

def generate_numbers():
    """ GENERATE one object/number at a time = Lazy List """
    print("Executing generate numbers()..")
    for  x in range(0, 11, 1):
        if x%2 == 0:
            yield x

def generate_numbers2():
    """ GENERATE one object/number at a time = Lazy List
        using a return and list comprehension, eek! """
    print("Executing generate numbers2()..")
    return( x for x in range(0, 11) if x%2==0 )


def main():
    """ Generate colleciton of numbers """

    # Try each of these with large numbers for range().

    for z in get_numbers():
        print(z)

    for z in generate_numbers():
        print(z)

    for z in generate_numbers2():
        print(z)

if __name__ == "__main__":
    main()
    sys.exit(0)
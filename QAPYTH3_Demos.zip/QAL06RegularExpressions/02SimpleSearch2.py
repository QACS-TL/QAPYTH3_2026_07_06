import re

test_string = 'The quick brown fox jumps over the lazy dog'

m = re.search(r"(lazy|fox)", test_string)
if m:
    print('Matched', m.groups())
    print('Starting at', m.start())
    print('Ending at', m.end())

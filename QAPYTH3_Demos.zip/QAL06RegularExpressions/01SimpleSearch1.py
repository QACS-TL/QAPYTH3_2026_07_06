import re
import sys




test_string = 'The quick brown fox jumps over the lazy dog'

m = re.search(r'(.o.)', test_string)
if m:
    print('Matched', m.groups()[0])
    print('Starting at', m.start())
    print('Ending at', m.end())


import re

line = 'words*separated*by*asterisks'
elems = re.split('[*]', line)
print(elems)

# Using str type split
elems = line.split("*")
print(elems)

line = 'root:;0.0:superuser,/root;/bin/sh'
elems = re.split('[:;.,]', line)
print(elems)

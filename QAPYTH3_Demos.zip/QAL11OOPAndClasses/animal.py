class Animal:

    count = 0
    def __init__(self, name, limbcount=4, age=0):
        self._constructed_flag = False
        self.name = name
        self._limbcount = limbcount
        self._age = age
        Animal.count += 1


    def eat(self, food):
        return f"I'm an animal called {self.name} eating {food}"

    def get_limbcount(self):
        return self._limbcount

    def set_limbcount(self, limbcount):
        if limbcount < 0:
            limbcount = 0
        self._limbcount = limbcount

    limbcount = property(get_limbcount, set_limbcount)

    @property
    def age(self):
        return self._age

    @age.setter
    def age(self, age):
        if age < 0 or age > 150:
            age = 0
        self._age = age

    def __str__(self):
        return f"I'm an animal called {self.name} and I have {self.limbcount} limbs and I am {self.age} years old"




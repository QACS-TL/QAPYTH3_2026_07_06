import unittest
import animal

class TestAnimal(unittest.TestCase):
    def test_initialiser(self):
        # Arrange
        ani = animal.Animal("Snider", 8, 2)
        # Act

        # Assert
        self.assertEqual("Snider", ani.name)
        self.assertEqual(8, ani.limbcount)
        self.assertEqual(2, ani.age)


    def test_eat(self):
        # Arrange
        name = "Snider"
        limbcount = 8
        age = 2
        food = "cheese"
        ani = animal.Animal(name, limbcount, age)

        # Act
        actual = ani.eat(food)

        # Assert
        self.assertEqual(f"I'm an animal called {name} eating {food}", actual)
        self.assertEqual(f"I'm an animal called {name} and I have {limbcount} limbs and I am {age} years old", ani.__str__())

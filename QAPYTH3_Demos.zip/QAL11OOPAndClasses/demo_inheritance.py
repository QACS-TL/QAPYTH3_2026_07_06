#! /bin/python
# Name:        demo_inheritance.py
# Author:      QA2.0, Donald Cameron
# Revision:    v1.0
# Description: This is an ultra realistic computer game with Tanks!
"""
    Game of Tanks!
"""

import sys
import tank2

def main():
    """ Main game """
    # Instantiate 3 new Tank objects.
    lancelot_tank = tank2.Tank("German", "Tiger")
    arthur_tank = tank2.Tank("British", "Churchill")
    robin_tank = tank2.Tank("American", "Sherman")

    tanks = {1:lancelot_tank, 2:arthur_tank, 3:robin_tank}


    # .. and the game begins.
    lancelot_tank.accel(41)
    arthur_tank.accel(33)

    robin_tank.rotate_left(385)
    robin_tank.accel(15)
    robin_tank.shoot()

    # ..and success!
    lancelot_tank.take_damage(40)
    arthur_tank.take_damage(62)

    # And now for some game visuals! Well at least a print statement!
    print(f"Health of Lancelot's Tank = {lancelot_tank._health}") # Why is this POOR Code?

    # Example of Operator Overloading.
    print(f"Status of Lancelot's and Arthur's Tanks = {lancelot_tank + arthur_tank}")

    # Example of Duck Typing, Tank can now Quack like a str!
    print(f"Status of Lancelot's Tank: {lancelot_tank}")

    # Lancelot has received a health boost!
    # Update and get health directly from private objects! Ugly and Poor!
    lancelot_tank._health = 90
    print(f"Lancelot's new health is {lancelot_tank._health}")

    # Examples of special GETTER and SETTER methods.
    # Internal methods accessing private data = better!
    lancelot_tank.set_health(100)
    print(f"Lancelot's new health is {lancelot_tank.get_health()}")

    # Using a property interface with one name.
    lancelot_tank.tank_health1 = 101
    print(f"Lancelot's new health is {lancelot_tank.tank_health1}")

    # Using property decorators
    lancelot_tank.tank_health2 = 105
    print(f"Lancelot's new health is {lancelot_tank.tank_health2}")

    #No such property!
    lancelot_tank.tank_healthX = 110
    print(f"Lancelot's new health is {lancelot_tank.tank_healthX}")

    # And testing our class method decorator.
    print(tank2.Tank.get_version())
    return None

if __name__ == "__main__":
    main()
    sys.exit(0)

from animal import Animal

class Dog(Animal):
    def __init__(self, name, limbcount, age, tail_length):
        self._tail_length = tail_length
        super().__init__(name,limbcount,age)

    def get_tail_length(self):
        return self._tail_length

    def set_tail_length(self, tail_length):
        if tail_length < 0:
            tail_length = 0
        self._tail_length = tail_length

    tail_length = property(get_tail_length, set_tail_length)

    def eat(self, food):
        return f"I'm a dog called {self.name} using some of my {self.limbcount} limbs to chew on a {food}. "

    def __str__(self):
        return f"{super().__str__()} but actually I'm a DOG and my tail length is {self._tail_length} cm"

class Cup:
    volume = 0
    colour = ""
    handle = False
    def __init__(self, volume=250, colour="transparent", handle=False):
        self.volume = volume
        self.colour = colour
        self.handle = handle

    def take_a_sip(self):
        self.volume -= 10

class TeaCup(Cup):
    def __init__(self):
        self.volume = 150
        self.colour = "white"

    def take_a_sip(self):
        self.volume -= 5

class Mug(Cup):
    def __init__(self):
        self.volume = 500
        self.colour = "orange"

cups = []

cups.append(Cup(300, "red"))
print(cups[0].volume)


cups.append(Cup(175, "green", True))

cups.append(Cup(handle=True, colour="blue"))

cups[1].color = "purple"

tc = TeaCup()
cups.append(tc)
cups.append(Mug())

print("*" * 20)

for cup in cups:
    print(cup.volume)
    cup.take_a_sip()
    print(cup.volume)


import animal
from dog import Dog


ani1 = animal.Animal("Abdul")

ani2 = animal.Animal("Tina", 6, 3)
# ani2.name = "Tina"
# ani2.limbcount = 8
ani2.age = 3


print(f"I'm an animal called {ani1.name} and I have {ani1.limbcount} limbs and I am {ani1.age} years old")
print(f"I'm an animal called {ani2.name} and I have {ani2.limbcount} limbs and I am {ani2.age} years old")


print(ani1.eat("bananas"))

# ani2._lambcount = -10
ani2.limbcount = -3
print(f"I'm an animal called {ani2.name} and I have {ani2.limbcount} limbs and I am {ani2.age} years old")

dog1 = Dog("Fido", 4, 7, 34)
print(f"I'm a dog called {dog1.name} and I have {dog1.limbcount} limbs, I am {dog1.age} years old and my tail is {dog1.tail_length} cm long")
print(dog1.eat("bone"))
print(dog1)
print(ani1)
